import React from 'react'

export default function Dashboard() {
  return (
    <div>
      <h1>This is the dashboard</h1>
    </div>
  )
}

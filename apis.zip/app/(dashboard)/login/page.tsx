import Login from '@/components/dashboard/login/Login'
import React from 'react'

export default function LoginPage() {
    return (
        <div>
            <Login />
        </div>
    )
}
